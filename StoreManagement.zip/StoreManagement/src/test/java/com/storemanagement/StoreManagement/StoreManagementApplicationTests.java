package com.storemanagement.StoreManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
